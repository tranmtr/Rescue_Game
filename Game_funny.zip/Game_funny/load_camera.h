#pragma once

#include "header.h"
#include "figure.h"

void loadCamera(SDL_Rect& camera, Figure Figure, const int& LEVEL_WIDTH, const int& LEVEL_HEIGHT);
