#pragma once

#include "header.h"

//Box collision detector
bool checkCollision(const SDL_Rect& a, const SDL_Rect& b );
