#pragma once

#include "header.h"

void loadLevel(const int& choose, string& pathMaze, int& LEVEL_WIDTH, int& LEVEL_HEIGHT, int& TOTAL_TILES, int& TOTAL_DRAGON);
